import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import static java.awt.Color.CYAN;

public class NewBook extends JFrame implements ActionListener {
    JButton Save_Button,Close_Button;
    JLabel BookId_Label,BookName_Label,AuthorName_Label,Price_Label,PublishedYear_Label,label;
    JTextField BookName_TextField,BookId_TextField,AuthorName_TextField,Price_TextField,PublishedYear_TextField;


    NewBook(){

        ImageIcon Saveicon= new ImageIcon("src/New/save(1).png");
        ImageIcon Closeicon= new ImageIcon("src/New/close.png");




        label=new JLabel("ENTER NEW BOOK!");
        label.setBounds(100,20,450,30);
        label.setFont(new Font("Serif",Font.BOLD,35));
        label.setForeground(Color.CYAN);







        BookId_Label=new JLabel("Book ID:");
        BookId_Label.setBounds(100,100,150,30);
        BookId_TextField=new JTextField();
        BookId_TextField.setBounds(250,100,200,30);
        BookId_Label.setFont(new Font("Serif", Font.BOLD, 16));
        BookId_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        BookId_TextField.setBackground(Color.WHITE);
        BookId_Label.setForeground(Color.orange);



        //
        BookName_Label=new JLabel("Book Name:");
        BookName_Label.setBounds(100,150,150,30);
        BookName_TextField=new JTextField();
        BookName_TextField.setBounds(250,150,200,30);
        BookName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        BookName_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        BookName_TextField.setBackground(Color.WHITE);
        BookName_Label.setForeground(Color.orange);

        //
        AuthorName_Label=new JLabel("Author:");
        AuthorName_Label.setBounds(100,200,150,30);
        AuthorName_TextField=new JTextField();
        AuthorName_TextField.setBounds(250,200,200,30);
        AuthorName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        AuthorName_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        AuthorName_TextField.setBackground(Color.WHITE);
        AuthorName_Label.setForeground(Color.orange);

        //
        Price_Label=new JLabel("Price:");
        Price_Label.setBounds(100,250,150,30);
        Price_TextField=new JTextField();
        Price_TextField.setBounds(250,250,200,30);
        Price_Label.setFont(new Font("Serif", Font.BOLD, 16));
        Price_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        Price_TextField.setBackground(Color.WHITE);
        Price_Label.setForeground(Color.orange);

        //
        PublishedYear_Label=new JLabel("Published Year:");
        PublishedYear_Label.setBounds(100,300,150,30);
        PublishedYear_TextField=new JTextField();
        PublishedYear_TextField.setBounds(250,300,200,30);
        PublishedYear_Label.setFont(new Font("Serif", Font.BOLD, 16));
        PublishedYear_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        PublishedYear_TextField.setBackground(Color.WHITE);
        PublishedYear_Label.setForeground(Color.orange);



        //
        Save_Button=new JButton("Save");
        Save_Button.setBounds(150,350,100,30);
        Save_Button.addActionListener(this);
        Save_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Save_Button.setBackground(Color.CYAN);
        Save_Button.setForeground(Color.BLACK);
        Save_Button.setIcon(Saveicon);

        Close_Button=new JButton("Close");
        Close_Button.setBounds(300,350,110,30);
        Close_Button.addActionListener(this);
        Close_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Close_Button.setBackground(Color.orange);
        Close_Button.setForeground(Color.BLACK);
        Close_Button.setIcon(Closeicon);

        setSize(600,450);
        getContentPane().setBackground(CYAN);
        setLocation(325,125);
        setLayout(null);
        add(Save_Button);
        add(Close_Button);
        add(BookId_Label);
        add(BookName_Label);
        add(AuthorName_Label);
        add(Price_Label);
        add(PublishedYear_Label);
        add(BookName_TextField);
        add(BookId_TextField);
        add(AuthorName_TextField);
        add(Price_TextField);
        add(PublishedYear_TextField);
        add(label);

        setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == Save_Button) {

            ///////////////////////////////////////////////////////////////////////////
            String Book_ID = BookId_TextField.getText();
            String Name = BookName_TextField.getText();
            String Publisher = AuthorName_TextField.getText();
            String Price = Price_TextField.getText();
            String Published_Year = PublishedYear_TextField.getText();

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }


            try {


                Connection con = DriverManager.getConnection("jdbc:mysql://@localhost:3306/kusbase", "root", "");





                String sql = "insert into New_Book values (?,?,?,?,?)";

                PreparedStatement pst = con.prepareStatement(sql);

                pst.setString(1, Book_ID);
                pst.setString(2, Name);
                pst.setString(3, Publisher);
                pst.setString(4, Price);
                pst.setString(5, Published_Year);

                pst.executeUpdate();


                con.close();
                JOptionPane.showMessageDialog(null, "Successfully Inserted");
                setVisible(false);
                new NewBook().setVisible(true);


            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Student Id Allready Exist!");

            }

        } else if (ae.getSource() == Close_Button) {
            setVisible(false);


        }

    }

}



