import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import static java.awt.Color.*;

public class IssueClass extends JFrame implements ActionListener {
    JButton Save_Button,Close_Button;
    JLabel BookId_Label,BookName_Label,StudentId_Label,StudentName_Label,IssueDate_Label,DueDate_Label,label;
    JTextField BookId_TextField,BookName_TextField,StudentId_TextField,StudentName_TextField,IssueDate_TextField,DueDate_TextField;


    IssueClass(){

        ImageIcon Saveicon= new ImageIcon("src/New/save(1).png");
        ImageIcon Closeicon= new ImageIcon("src/New/close.png");




        label=new JLabel("Issue Book!");
        label.setBounds(150,20,300,30);
        label.setFont(new Font("Serif",Font.BOLD,30));
        label.setForeground(red);

        BookId_Label=new JLabel("Book ID:");
        BookId_Label.setBounds(100,100,150,30);
        BookId_TextField=new JTextField();
        BookId_TextField.setBounds(250,100,200,30);
        BookId_Label.setFont(new Font("Serif", Font.BOLD, 16));
        BookId_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        BookId_TextField.setBackground(Color.WHITE);
        BookId_Label.setForeground(Color.orange);



        //
        BookName_Label=new JLabel("Book Name:");
        BookName_Label.setBounds(100,150,150,30);
        BookName_TextField=new JTextField();
        BookName_TextField.setBounds(250,150,200,30);
        BookName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        BookName_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        BookName_TextField.setBackground(Color.WHITE);
        BookName_Label.setForeground(Color.orange);


        //
        StudentId_Label=new JLabel("Student ID:");
        StudentId_Label.setBounds(100,200,150,30);
        StudentId_TextField=new JTextField();
        StudentId_TextField.setBounds(250,200,200,30);
        StudentId_Label.setFont(new Font("Serif", Font.BOLD, 16));
        StudentId_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        StudentId_TextField.setBackground(Color.WHITE);
        StudentId_Label.setForeground(Color.orange);

        //
        StudentName_Label=new JLabel("Student Name:");
        StudentName_Label.setBounds(100,250,150,30);
        StudentName_TextField=new JTextField();
        StudentName_TextField.setBounds(250,250,200,30);
        StudentName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        StudentName_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        StudentName_TextField.setBackground(Color.WHITE);
        StudentName_Label.setForeground(Color.orange);

        //
        IssueDate_Label=new JLabel("Issue Date:");
        IssueDate_Label.setBounds(100,300,150,30);
        IssueDate_TextField=new JTextField();
        IssueDate_TextField.setBounds(250,300,200,30);
        IssueDate_Label.setFont(new Font("Serif", Font.BOLD, 16));
        IssueDate_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        IssueDate_TextField.setBackground(Color.WHITE);
        IssueDate_Label.setForeground(Color.orange);

        //
        DueDate_Label=new JLabel("Due Date:");
        DueDate_Label.setBounds(100,350,150,30);
        DueDate_TextField=new JTextField();
        DueDate_TextField.setBounds(250,350,200,30);
        DueDate_Label.setFont(new Font("Serif", Font.BOLD, 16));
        DueDate_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        DueDate_TextField.setBackground(Color.WHITE);
        DueDate_Label.setForeground(Color.orange);

        Save_Button=new JButton("Save");
        Save_Button.setBounds(150,400,100,30);
        Save_Button.addActionListener(this);
        Save_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Save_Button.setBackground(YELLOW);
        Save_Button.setForeground(Color.BLACK);
        Save_Button.setIcon(Saveicon);

        Close_Button=new JButton("Close");
        Close_Button.setBounds(300,400,110,30);
        Close_Button.addActionListener(this);
        Close_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Close_Button.setBackground(PINK);
        Close_Button.setForeground(Color.BLACK);
        Close_Button.setIcon(Closeicon);

        setSize(600,500);
        setBackground(BLUE);
        //setIconImage(icon.getImage());


        setLocation(325,125);
        getContentPane().setBackground(CYAN);
        setLayout(null);
        add(Save_Button);
        add(Close_Button);

        add(BookId_Label);
        add(BookName_Label);
        add(StudentId_Label);
        add(BookName_TextField);
        add(BookId_TextField);
        add(StudentName_Label);
        add(IssueDate_Label);
        add(StudentName_TextField);
        add(IssueDate_TextField);
        add(DueDate_TextField);
        add(StudentId_TextField);
        add(DueDate_Label);
        add(label);

        setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent ae) {if(ae.getSource()==Save_Button){

        ///////////////////////////////////////////////////////////////////////////

        String BookId_Label = BookId_TextField.getText();
        String BookName_Label = BookName_TextField.getText();
        String StudentId_Label = StudentId_TextField.getText();
        String StudentName_Label = StudentName_TextField.getText();
        String IssueDate_Label = IssueDate_TextField.getText();
        String DueDate_Label= DueDate_TextField.getText();
        String Returned="No";


        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        String url = "jdbc:mysql://@localhost:3306/kusbase";
        String username = "root";
        String password = "";

        try {


            Connection con = DriverManager.getConnection(url, username, password);


            String sql = "insert into Student_Table values (?,?,?,?,?,?,?)";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, BookId_Label);
            pst.setString(2, BookName_Label);
            pst.setString(3, StudentId_Label);
            pst.setString(4, StudentName_Label);
            pst.setString(5, IssueDate_Label);
            pst.setString(6, DueDate_Label);
            pst.setString(7,Returned);

            pst.executeUpdate();



            con.close();
            JOptionPane.showMessageDialog(null, "Successfully Updated");
            setVisible(false);
            new IssueClass().setVisible(true);


        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Something went wrong!");

        }

    } else if (ae.getSource() == Close_Button) {
        setVisible(false);

        //////////////////////////////////////////////////////////////////////////
    }
    }

}




