package New;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
public class Icons extends javax.swing.JFrame {
    Image img = Toolkit.getDefaultToolkit().getImage("src/New/building (2).jpg");
    public Icons() throws IOException {


        this.setContentPane(new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(img, 0, 0, null);
            }
        });



        pack();
        setVisible(true);
    }
    public static void main(String[] args) throws Exception {
        new Icons();
    }
}