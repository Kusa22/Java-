import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class FrameStatistcs extends JFrame implements ActionListener {



   public JTextField textbox;
    JLabel label;
    JButton SearchByIdButton,SearchAllButton,ClearButton;

    JPanel panel1,panel2,panel3;
    DefaultTableModel model;
    JTable table;
    JTableHeader tableHeader;
    JScrollPane scroll;



    public  FrameStatistcs() {

        tableHeader=new JTableHeader();


         model = new DefaultTableModel();
         panel3=new JPanel();
         textbox=new JTextField();
         table = new JTable(model);
         scroll=new JScrollPane(table);
         panel1 = new JPanel();
         panel2 = new JPanel();
         label=new JLabel();



        table.setModel(model);
        table.setBackground(Color.CYAN);
        table.setFont(new Font("Serif",Font.ITALIC,15));
        scroll.setBounds(10,0,790,530);

        tableHeader=table.getTableHeader();
        tableHeader.setFont(new Font("Serif",Font.BOLD,14));
        tableHeader.setBackground(Color.pink);








        model.addColumn("BOOK ID");
        model.addColumn("BOOK NAME");
        model.addColumn("STUDENT ID");
        model.addColumn("STUDENT NAME");
        model.addColumn("ISSUE DATE");
        model.addColumn("DUE DATE");
        model.addColumn("RETURNED");



        panel3.add(scroll);
        panel3.setBackground(Color.green);
        panel3.setBounds(400,0,790,530);
        panel3.setLayout(null);
        panel3.setVisible(true);
















           SearchByIdButton = new JButton("Search By ID");
           SearchAllButton = new JButton("SEARCH ALL");
           ClearButton = new JButton("CLEAR");




           panel1.setLayout(null);
           panel1.setBackground(Color.orange);


           textbox.setBounds(200,40,200,50);
           textbox.setBackground(Color.lightGray);
           textbox.setFont(new Font("Serif",Font.BOLD,20));

           label = new JLabel("ENTER BOOK ID:");
           label.setBounds(10, 30, 200, 80);
           label.setFont(new Font("Serif",Font.BOLD,20));

           


        SearchByIdButton.setFocusable(false);
        SearchByIdButton.setFont(new Font("Serif", Font.BOLD, 20));
        SearchByIdButton.setBounds(200, 130, 200, 50);
        SearchByIdButton.setBackground(Color.CYAN);
        SearchByIdButton.addActionListener(this);




        SearchAllButton.setFocusable(false);
        SearchAllButton.setFont(new Font("Serif", Font.BOLD, 20));
        SearchAllButton.setBounds(200, 200, 200, 50);
        SearchAllButton.setBackground(Color.CYAN);
        SearchAllButton.addActionListener(this);



        ClearButton.setFocusable(false);
        ClearButton.setFont(new Font("Serif", Font.BOLD, 20));
        ClearButton.setBounds(200, 300, 200, 50);
        ClearButton.setBackground(Color.CYAN);
        ClearButton.addActionListener(this);



        panel1.setLocation(0, 120);
        panel1.add(textbox);
        panel1.add(label);
        panel1.add(SearchByIdButton);
        panel1.add(SearchAllButton);
        panel1.add(ClearButton);
        panel1.setBounds(0, 0, 410, 700);


        /////////////////////////////////////////////////////





        this.add(panel1);
        this.add(panel3);
        this.setSize(1200, 580);
        this.getContentPane().setBackground(Color.YELLOW);
        this.setLocation(40, 120);
        this.setLayout(null);
        this.setVisible(true);
    }






    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==SearchAllButton){
            SearchAllClass();
        }
        if (e.getSource()==SearchByIdButton){
            SearchByIdClass();
        }
        if (e.getSource()==ClearButton){
            model.removeRow(0);
        }
    }


      void SearchByIdClass() {

          try {
              Class.forName("com.mysql.cj.jdbc.Driver");
              Connection con = DriverManager.getConnection("jdbc:mysql://localhost/kusbase", "root", "");
              PreparedStatement pstm = con.prepareStatement("SELECT * FROM Student_Table where Book_Id='"+textbox.getText()+"'");
              ResultSet Rs = pstm.executeQuery();
              while(Rs.next()){
                  model.addRow(new Object[]{Rs.getString(1), Rs.getString(2),Rs.getString(3),Rs.getString(4),Rs.getString(5),Rs.getString(6),Rs.getString(7)});
              }
          } catch (Exception e) {
              System.out.println(e.getMessage());
          }

        }

        void SearchAllClass()
        {

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/kusbase", "root", "");
                PreparedStatement pstm = con.prepareStatement("SELECT * FROM Student_Table");
                ResultSet Rs = pstm.executeQuery();
                while(Rs.next()){
                    model.addRow(new Object[]{Rs.getString(1), Rs.getString(2),Rs.getString(3),Rs.getString(4),Rs.getString(5),Rs.getString(6),Rs.getString(7)});
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

}