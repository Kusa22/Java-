import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class NewStudent extends JFrame implements ActionListener {






    JButton Save_Button,Close_Button;
    JLabel StudentName_Label,StudentId_Label,FatherName_Label,Department_Label,CollegeName_Label,label;
    JTextField StudentName_TextField,StudentId_TextField,FatherName_TextField;

    JComboBox checkbox1,checkbox2;


    NewStudent(){

        ImageIcon Saveicon= new ImageIcon("src/New/save(1).png");
        ImageIcon Closeicon= new ImageIcon("src/New/close.png");

        label=new JLabel("ENTER STUDENT INFO!");
        label.setBounds(100,20,450,30);
        label.setFont(new Font("Serif",Font.BOLD,35));
        label.setForeground(Color.green);



        //
        CollegeName_Label=new JLabel("Colleges:");
        String College[]={"College Of Computing and Informatics","College of Agriculture","College Of Law","College Of Healthy","College Of Business and Economics","College Of Computational Science","College Of Veterinary And Animal Science"};
        checkbox1=new JComboBox(College);
        CollegeName_Label.setBounds(100,100,100,30);
        checkbox1.setBounds(250,100,300,30);
        CollegeName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        checkbox1.setFont(new Font("Serif", Font.BOLD, 16));
        checkbox1.setEditable(true);
        checkbox1.setBackground(Color.WHITE);
        CollegeName_Label.setForeground(Color.CYAN);


        //
        String department[]={"Software Engineering","Computer Science","Information Science","Statistics","Information System","Civil Engineering","Animal Science","Mathematics","Biology","Electrical Engineering","Mechanical Engineering","Agro_Economics","Veterinary Medicine","Architectural Engineering","Medical Laboratory"};
        Department_Label=new JLabel("Department:");
        checkbox2=new JComboBox(department);
        Department_Label.setBounds(100,150,100,30);
        checkbox2.setBounds(250,150,300,30);
        Department_Label.setFont(new Font("Serif", Font.BOLD, 16));
        checkbox2.setFont(new Font("Serif", Font.BOLD, 16));
        checkbox2.setEditable(true);
        checkbox2.setBackground(Color.WHITE);
        Department_Label.setForeground(Color.CYAN);




        //

        StudentId_Label=new JLabel("Student ID:");
        StudentId_Label.setBounds(100,200,100,30);
        StudentId_TextField=new JTextField();
        StudentId_TextField.setBounds(250,200,200,30);
        StudentId_Label.setFont(new Font("Serif", Font.BOLD, 16));
        StudentId_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        StudentId_TextField.setBackground(Color.WHITE);
        StudentId_Label.setForeground(Color.CYAN);

        //

        StudentName_Label=new JLabel("Student Name:");
        StudentName_Label.setBounds(100,250,200,30);
        StudentName_TextField=new JTextField();
        StudentName_TextField.setBounds(250,250,200,30);
        StudentName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        StudentName_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        StudentName_TextField.setBackground(Color.WHITE);
        StudentName_Label.setForeground(Color.CYAN);





        //
        FatherName_Label=new JLabel("Father Name:");
        FatherName_Label.setBounds(100,300,100,30);
        FatherName_TextField=new JTextField();
        FatherName_TextField.setBounds(250,300,200,30);
        FatherName_Label.setFont(new Font("Serif", Font.BOLD, 16));
        FatherName_TextField.setFont(new Font("Serif", Font.BOLD, 16));
        FatherName_TextField.setBackground(Color.WHITE);
        FatherName_Label.setForeground(Color.CYAN);


        Save_Button=new JButton("Save");
        Save_Button.setBounds(200,350,100,30);
        Save_Button.addActionListener(this);
        Save_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Save_Button.setBackground(Color.yellow);
        Save_Button.setForeground(Color.BLACK);
        Save_Button.setIcon(Saveicon);

        Close_Button=new JButton("Close");
        Close_Button.setBounds(320,350,110,30);
        Close_Button.addActionListener(this);
        Close_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Close_Button.setBackground(Color.pink);
        Close_Button.setForeground(Color.BLACK);
        Close_Button.setIcon(Closeicon);

        setSize(700,450);
        setLocation(325,125);
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        add(Save_Button);
        add(Close_Button);
        add(checkbox1);
        add(checkbox2);
        add(StudentName_Label);
        add(StudentId_Label);
        add(FatherName_Label);
        add(StudentName_TextField);
        add(StudentId_TextField);
        add(CollegeName_Label);
        add(FatherName_TextField);
        add(Department_Label);
        add(label);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == Save_Button) {

            ///////////////////////////////////////////////////////////////////////////

            String StudentId = StudentId_TextField.getText();
            String StudentName = StudentName_TextField.getText();
            String FatherName = FatherName_TextField.getText();
            String CollegeName = checkbox1.getSelectedItem().toString();
            String Department = checkbox2.getSelectedItem().toString();


            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
            String url = "jdbc:mysql://@localhost:3306/kusbase";
            String username = "root";
            String password = "";

            try {


                Connection con = DriverManager.getConnection(url, username, password);


                String sql = "insert into Haramaya_Student_Table values (?,?,?,?,?)";

                PreparedStatement pst = con.prepareStatement(sql);


                pst.setString(1, CollegeName);
                pst.setString(2, Department);
                pst.setString(3, StudentId);
                pst.setString(4, StudentName);
                pst.setString(5, FatherName);


                pst.executeUpdate();



                con.close();
                JOptionPane.showMessageDialog(null, "Successfully Updated");
                setVisible(false);
                new NewStudent().setVisible(true);


            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Student Id Allready Exist!");

            }

        } else if (ae.getSource() == Close_Button) {
            setVisible(false);

            //////////////////////////////////////////////////////////////////////////
        }
    }
    }


