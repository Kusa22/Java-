import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.awt.Color.*;

public class LoginPage extends JFrame implements ActionListener {
    JButton Login_Button,Close_Button;
    JLabel Name_Label,Password_Label,label,label1;
    JTextField NameTextField;
    JPasswordField PasswordTextField;

    LoginPage(){
        ImageIcon LoginIcon= new ImageIcon("src/New/login.png");
        label=new JLabel("LOGIN INTO LIBRARY MANAGEMENT!");
        label.setBounds(50,20,600,30);
        label.setFont(new Font("Algerian",Font.BOLD,30));
        label.setForeground(red);

        label1=new JLabel("Login");
        label1.setBounds(230,50,400,100);
        label1.setFont(new Font("Algerian",Font.BOLD,30));
        label1.setForeground(GREEN);




        ImageIcon Saveicon= new ImageIcon("src/New/save(1).png");
        ImageIcon Closeicon= new ImageIcon("src/New/close.png");





        NameTextField=new JTextField();
        Name_Label=new JLabel("User Name:");
        Name_Label.setBounds(100,150,100,30);
        Name_Label.setFont(new Font("Serif", Font.BOLD, 16));
        NameTextField.setFont(new Font("Serif", Font.BOLD, 16));
        NameTextField.setBackground(Color.WHITE);
        Name_Label.setForeground(Color.orange);

        NameTextField.setBounds(200,150,200,30);


        Password_Label=new JLabel("Password:");
        PasswordTextField=new JPasswordField();
        Password_Label.setBounds(100,200,100,30);
        Password_Label.setFont(new Font("Serif", Font.BOLD, 16));
        PasswordTextField.setFont(new Font("Serif", Font.BOLD, 16));
        PasswordTextField.setToolTipText("Enter Your Password Here:");
        PasswordTextField.setEchoChar('*');
        PasswordTextField.setBackground(Color.WHITE);
        Password_Label.setForeground(Color.orange);

        PasswordTextField.setBounds(200,200,200,30);


        Login_Button=new JButton("Login");
        Login_Button.setBounds(150,300,120,30);
        Login_Button.addActionListener(this);
        Login_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Login_Button.setBackground(orange);
        Login_Button.setForeground(Color.BLACK);
        Login_Button.setIcon(Saveicon);

        Close_Button=new JButton("Close");
        Close_Button.setBounds(300,300,120,30);
        Close_Button.addActionListener(this);
        Close_Button.setFont(new Font("Serif", Font.BOLD, 16));
        Close_Button.setBackground(MAGENTA);
        Close_Button.setForeground(Color.BLACK);
        Close_Button.setIcon(Closeicon);

        setSize(700,450);
        getContentPane().setBackground(CYAN);
        setLocation(325,125);
        setLayout(null);
        add(Login_Button);
        add(Close_Button);
        add(Name_Label);
        add(Password_Label);
        add(PasswordTextField);
        add(NameTextField);
        add(label);
        add(label1);

        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Login_Button)
        {
          if (NameTextField.getText().equals("admin") && PasswordTextField.getText().equals("admin")){

              new Home();

              setVisible(false);
          }
          else{
              JOptionPane.showMessageDialog(null,"Please Enter Correct User Name And Password");
          }
        }
        else if (e.getSource()==Close_Button) {

           setVisible(false);
        }

    }

    public static void main(String[] args) {
        new LoginPage();

    }

}
