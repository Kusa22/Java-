import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame implements ActionListener {
    JButton NewStudent_Button,NewBook_Button,StatisticsButton,IssueButton,ReturnButton,LogoutButton;


    Home(){

        Image img = Toolkit.getDefaultToolkit().getImage("src/New/building(2).png");
            setContentPane(new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(img, 0, 0, null);
            }
        });




        ImageIcon backg=new ImageIcon("src/New/buliding.png");
        JLabel label=new JLabel();
        label.setIcon(backg);

        ImageIcon ima=new ImageIcon("src/New/buliding.png");
        ImageIcon studentIcon=new ImageIcon("src/New/newstud.png");
        ImageIcon newbook=new ImageIcon("src/New/bookgre.png");

        ImageIcon statica=new ImageIcon("src/New/book.png");
        ImageIcon issue=new ImageIcon("src/New/openbook.png");
        ImageIcon returnd=new ImageIcon("src/New/books.png");
        ImageIcon logout=new ImageIcon("src/New/signout1.png");




        //
        NewStudent_Button=new JButton("New Student");
        NewStudent_Button.setBounds(25,20,200,60);
        NewStudent_Button.setFont(new Font("Oswald", Font.PLAIN, 16));
        NewStudent_Button.setBackground(Color.CYAN);

        //
        NewStudent_Button.setIcon(studentIcon);
        NewStudent_Button.setFocusable(false);
        NewStudent_Button.addActionListener(this);

        //
        NewBook_Button=new JButton("New Book");
        NewBook_Button.setBounds(230,20,200,60);
        NewBook_Button.setFocusable(false);
        NewBook_Button.setFont(new Font("Algerian", Font.PLAIN, 16));

        //
        NewBook_Button.setBackground(Color.CYAN);
        NewBook_Button.setIcon(newbook);
        NewBook_Button.addActionListener(this);

        //
        StatisticsButton=new JButton("Statistics");
        StatisticsButton.setBounds(435,20,200,60);
        StatisticsButton.setFocusable(false);
        StatisticsButton.setFont(new Font("Algerian", Font.PLAIN, 16));

        //
        StatisticsButton.setBackground(Color.CYAN);
        StatisticsButton.setIcon(statica);
        StatisticsButton.addActionListener(this);

        //
        IssueButton=new JButton("Issue Book");
        IssueButton.setBounds(640,20,200,60);
        IssueButton.setFocusable(false);
        IssueButton.setFont(new Font("Algerian", Font.PLAIN, 16));

        //
        IssueButton.setBackground(Color.CYAN);
        IssueButton.setIcon(issue);
        IssueButton.addActionListener(this);

        //
        ReturnButton=new JButton("Return Book");
        ReturnButton.setBounds(845,20,200,60);
        ReturnButton.setFocusable(false);
        ReturnButton.setFont(new Font("Algerian", Font.PLAIN, 16));

        //
        ReturnButton.setBackground(Color.CYAN);
        ReturnButton.setIcon(returnd);
        ReturnButton.addActionListener(this);

        //
        LogoutButton=new JButton("Logout");
        LogoutButton.setBounds(1050,20,200,60);
        LogoutButton.setFocusable(false);
        LogoutButton.setFont(new Font("Algerian", Font.PLAIN, 16));

        //
        LogoutButton.setBackground(Color.CYAN);
        LogoutButton.setIcon(logout);
        LogoutButton.setHorizontalTextPosition(JButton.RIGHT);
        LogoutButton.addActionListener(this);





        setSize(1300,800);
        setIconImage(ima.getImage());
        setLayout(null);

        add(NewBook_Button);
        add(NewStudent_Button);
        add(IssueButton);

        add(ReturnButton);
        add(LogoutButton);
        add(StatisticsButton);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==NewStudent_Button){

           NewStudent newStudent= new NewStudent();

        }
       else if(e.getSource()==NewBook_Button){



            NewBook newBook=new NewBook();

        }
        else if(e.getSource()==StatisticsButton){


            FrameStatistcs statist=new FrameStatistcs();


        }
        else if(e.getSource()==IssueButton){

            IssueClass issueClass=new IssueClass();

        }
        else if(e.getSource()==ReturnButton){

            ReturnClass returnClass=new ReturnClass();

        }
        else if(e.getSource()==LogoutButton){

            System.exit(0);


        }

    }

}

